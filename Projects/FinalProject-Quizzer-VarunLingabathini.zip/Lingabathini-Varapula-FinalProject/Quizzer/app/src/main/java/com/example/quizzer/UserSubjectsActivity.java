package com.example.quizzer;

import android.os.AsyncTask;

public class UserSubjectsActivity
{
    private class GetQuizList extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }
    }
}
