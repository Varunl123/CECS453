package com.example.fragment2;

public interface OnButtonPressListener {
    void onButtonPressed(String msg);
}
